Acrylic Case for the Intel Edison Breakout Board

Adam Heinrich, 2014

Link: http://adamheinrich.com/blog/2016/05/acrylic-case-for-the-intel-edison-breakout-board/

Licensed under CC BY-SA 4.0 (http://creativecommons.org/licenses/by-sa/4.0/).
